import styled from "styled-components";

export const GlobalContainer = styled.div`  
    padding: 0px;
    margin: -8px;
`;
