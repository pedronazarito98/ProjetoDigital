export const employees = [
    { 
        "name": "Mark Zuckerberg" ,
        "description" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet diam at lacus efficitur ornare. Fusce a ex viverra, dictum urna in, semper felis."
    },
    { 
        "name": "Mark Zuckerberg" ,
        "description" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet diam at lacus efficitur ornare. Fusce a ex viverra, dictum urna in, semper felis."
    },
    { 
        "name": "Mark Zuckerberg" ,
        "description" : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet diam at lacus efficitur ornare. Fusce a ex viverra, dictum urna in, semper felis."
    }
]